Eric Xie
hx8rc

Algorithm:
1. Sort rooms by ascending initial capacity
2. Loop forward through the rooms, renovating each room with an increased or unchanged capacity
3. Sort rooms by ascending final capacity
4. Loop backward through the rooms, renovating each room with a decreased capacity

etc:
- Program sorts input via Bubblesort. 
